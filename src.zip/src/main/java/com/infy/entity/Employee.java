package com.infy.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="emp_id")
	private Integer empId;
	@Column(name="email_id")
	private String emailId;
	private String name;
	@Column(name="phone_no")
	private String phoneNo;
	private char gender;
	//private Date dateOfBirth;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.getEmpId() == null) ? 0 : this.getEmpId().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (this.getEmpId() == null) {
			if (other.getEmpId() != null)
				return false;
		} 
		else if (!this.getEmpId().equals(other.getEmpId()))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", emailId=" + emailId + ", name=" + name + ", phoneNo=" + phoneNo + ", gender=" + gender + "]";
				
	}
}
