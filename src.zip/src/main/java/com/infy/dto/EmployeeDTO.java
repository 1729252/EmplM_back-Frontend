package com.infy.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class EmployeeDTO {
	private Integer empId;
	@Email(message = "{employee.emailid.invalid}")
	@NotNull(message = "{employee.emailid.absent}")
	private String emailId;
	
	@NotNull(message = "{employee.name.absent}")
	@Pattern(regexp = "[A-Za-z]+( [A-Za-z]+)*", message = "{employee.name.invalid}")
	private String name;
	private String phoneNo;
	private char gender;
	
	
	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}



	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}



	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}







	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", emailId=" + emailId + ", name=" + name + ", phoneNo=" + phoneNo + ", gender=" + gender + "]";
				
	}
}
