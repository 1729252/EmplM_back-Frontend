package com.infy.service;

import java.util.List;

import com.infy.dto.EmployeeDTO;
import com.infy.exception.InfyEmployeeException;

public interface EmployeeService {
	public Integer addEmployee(EmployeeDTO employee) throws InfyEmployeeException;
	public EmployeeDTO getEmployee(Integer empId) throws InfyEmployeeException;
	public List<EmployeeDTO> findAll() throws InfyEmployeeException;
	public void updateEmployee(Integer empId, String emailId) throws InfyEmployeeException;
}
