package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.infy.dto.EmployeeDTO;
import com.infy.entity.Employee;
import com.infy.exception.InfyEmployeeException;
import com.infy.repository.EmployeeRepository;

@Service(value = "employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	private static Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepository;
	
	// Insert new employee details
	@Override
	public Integer addEmployee(EmployeeDTO employeeDto) throws InfyEmployeeException {
		
		Optional<Employee> optional = employeeRepository.findById(employeeDto.getEmpId());
		if (optional.isPresent())
			throw new InfyEmployeeException("Service.EMPLOYEE_FOUND");
		Employee employee = new Employee();
		
		employee.setEmailId(employeeDto.getEmailId());
		employee.setEmpId(employeeDto.getEmpId());
		employee.setGender(employeeDto.getGender());
		employee.setName(employeeDto.getName());
		employee.setPhoneNo(employeeDto.getPhoneNo());
		Employee employee1 = employeeRepository.save(employee);
		logger.info("Employee details added");
		return employee1.getEmpId();
		
	}

	// Fetch each employee details using their ID
	@Override
	public EmployeeDTO getEmployee(Integer empId) throws InfyEmployeeException {
		
		Optional<Employee> optional = employeeRepository.findById(empId);
		Employee employee = optional.orElseThrow(() -> new InfyEmployeeException("Service.EMPLOYEE_NOT_FOUND"));
		EmployeeDTO employeeDto = new EmployeeDTO();
		
		employeeDto.setEmailId(employee.getEmailId());
		employeeDto.setEmpId(employee.getEmpId());
		employeeDto.setGender(employee.getGender());
		employeeDto.setName(employee.getName());
		employeeDto.setPhoneNo(employee.getPhoneNo());
		logger.info("Details of the employee are fetched");
		return employeeDto;
	}

	// Get All employee details
	@Override
	public List<EmployeeDTO> findAll() throws InfyEmployeeException {
		Iterable<Employee> employees = employeeRepository.findAll();
		List<EmployeeDTO> employeeDTOs = new ArrayList<>();
		employees.forEach(emp -> {
			EmployeeDTO employeeDto = new EmployeeDTO();
			employeeDto.setEmpId(emp.getEmpId());
			employeeDto.setEmailId(emp.getEmailId());
			employeeDto.setGender(emp.getGender());
			employeeDto.setName(emp.getName());
			employeeDto.setPhoneNo(emp.getPhoneNo());
			employeeDTOs.add(employeeDto);
		});
		if (employeeDTOs.isEmpty())
			throw new InfyEmployeeException("Service.EMPLOYEE_NOT_FOUND");

		logger.info("All employee details are fetched");
		return employeeDTOs;
	}

	//Update employee details
	@Override
	public void updateEmployee(Integer empId, String emailId) throws InfyEmployeeException {
		Optional<Employee> optional = employeeRepository.findById(empId);
		Employee emp = optional.orElseThrow(() -> new InfyEmployeeException("Service.EMPLOYEE_NOT_FOUND"));
		emp.setEmailId(emailId);
		
	}

}





