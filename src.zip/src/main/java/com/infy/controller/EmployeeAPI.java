package com.infy.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.infy.dto.EmployeeDTO;

import com.infy.exception.InfyEmployeeException;
import com.infy.service.EmployeeService;
import com.infy.service.EmployeeServiceImpl;

@RestController
//@RequestMapping
public class EmployeeAPI {
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private Environment environment;
	
	private static Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	
	//All Employees's details
	@GetMapping(value = "/employees")
	public ResponseEntity<List<EmployeeDTO>> findAll() throws InfyEmployeeException {
		List<EmployeeDTO> empList = employeeService.findAll();
		return new ResponseEntity<>(empList, HttpStatus.OK);
	}
	
	//ID specific Employee's details
	@GetMapping(value = "/employees/{empId}")
	public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable Integer empId) throws InfyEmployeeException {
		EmployeeDTO emp = employeeService.getEmployee(empId);
		return new ResponseEntity<>(emp, HttpStatus.OK);
	}
	
	//Adding a new Employee's details
	@PostMapping(value = "/employees")
	public ResponseEntity<String> addEmployee(@Valid @RequestBody EmployeeDTO employee) throws InfyEmployeeException {
		Integer empId = employeeService.addEmployee(employee);
		String successMessage = environment.getProperty("API.INSERT_SUCCESS") + empId;
		return new ResponseEntity<>(successMessage, HttpStatus.CREATED);
	}
	
	//Updating ID specific Employee's detail
	@PutMapping(value = "/employees/{empId}")
	public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable Integer empId, @RequestBody EmployeeDTO employee) throws InfyEmployeeException{
		employeeService.updateEmployee(empId, employee.getEmailId());
		//String successMessage = environment.getProperty("API.UPDATE_SUCCESS");
		logger.info("Employee's e-mail has been updated successfully.");
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
