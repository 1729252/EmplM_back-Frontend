drop database if exists employee_db;
create database employee_db;
use employee_db;

create table employee(
	emp_id int auto_increment,
	email_id varchar(50),
	name varchar(50),
	phone_no varchar(10),
	gender char,
	
	constraint ps_emp_id_pk primary key (emp_id)
);

insert into employee (emp_id, email_id, name, phone_no, gender) values (1, 'riya@infy.com', 'Riya Pal', '1325476983', 'F');
insert into employee (emp_id, email_id, name, phone_no, gender) values (2, 'riya01@infy.com', 'Riya Mehta', '1325476389', 'F');
insert into employee (emp_id, email_id, name, phone_no, gender) values (3, 'priya@infy.com', 'Priya Sahoo', '1895476983', 'F');
insert into employee (emp_id, email_id, name, phone_no, gender) values (4, 'riyaz@infy.com', 'Riyaz Ali', '1325476983', 'M');
insert into employee (emp_id, email_id, name, phone_no, gender) values (5, 'amit@infy.com', 'Amit Ghosh', '1325776983', 'M');
insert into employee (emp_id, email_id, name, phone_no, gender) values (6, 'ahil@infy.com', 'Ahil Gupta', '1455476981', 'M');
insert into employee (emp_id, email_id, name, phone_no, gender) values (7, 'rimi@infy.com', 'Rimi Dey', '1325666683', 'F');
insert into employee (emp_id, email_id, name, phone_no, gender) values (8, 'yash@infy.com', 'Yash Singh', '1325471111', 'M');


commit;
select * from employee;